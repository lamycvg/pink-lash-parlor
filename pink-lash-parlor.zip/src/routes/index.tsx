import { createFileRoute } from "@tanstack/react-router";
import { useRef, type MouseEvent, type ReactNode } from "react";
import { Hero3D } from "@/components/Hero3D";
import p1 from "@/assets/photo1.jpg.asset.json";
import p2 from "@/assets/photo2.jpg.asset.json";
import p3 from "@/assets/photo3.jpg.asset.json";
import p4 from "@/assets/photo4.jpg.asset.json";
import p5 from "@/assets/photo5.jpg.asset.json";
import p6 from "@/assets/photo6.jpg.asset.json";

export const Route = createFileRoute("/")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Ami Beauté Atelier — Extension Ciglia a Moncalieri, Torino" },
      { name: "description", content: "Extension ciglia in un atelier rosa a tema Hello Kitty. Via Moncalieri, Torino. Prenota su Instagram @ami_beauteatelier." },
      { property: "og:title", content: "Ami Beauté Atelier — Extension Ciglia" },
      { property: "og:description", content: "Il tuo atelier ciglia rosa a Torino. Prenota su Instagram e TikTok." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const IG = "https://instagram.com/ami_beauteatelier";
const TT = "https://www.tiktok.com/@ami_beauteatlier";

function Tilt({ children, className = "" }: { children: ReactNode; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const move = (e: MouseEvent) => {
    const el = ref.current; if (!el) return;
    const r = el.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width - 0.5;
    const y = (e.clientY - r.top) / r.height - 0.5;
    el.style.transform = `perspective(900px) rotateY(${x * 18}deg) rotateX(${-y * 18}deg) scale(1.03)`;
  };
  const leave = () => { if (ref.current) ref.current.style.transform = ""; };
  return (
    <div ref={ref} onMouseMove={move} onMouseLeave={leave} className={`tilt-card ${className}`}>
      {children}
    </div>
  );
}

const photos = [
  { src: p1.url, label: "Prima & dopo" },
  { src: p2.url, label: "Volume" },
  { src: p3.url, label: "Lash card" },
  { src: p4.url, label: "Ami Beauté card" },
  { src: p5.url, label: "Il nostro angolo" },
  { src: p6.url, label: "La postazione" },
];

const policy = [
  "Siate sempre puntuali",
  "Per spostare o annullare avvisate 48/24h prima",
  "Comunicate eventuali persone extra all'appuntamento",
  "Arrivate totalmente struccate",
  "Non applicate prodotti oleosi prima dell'appuntamento",
  "Evitate caffè o bevande energetiche",
  "Avvisate se serve una rimozione prima del trattamento",
  "Abbiate pazienza, la bellezza richiede tempo",
];

const aftercare = [
  "Non usare mai mascara o piegaciglia",
  "Evita il trucco pesante sulla palpebra",
  "Dormi senza strofinare le ciglia",
  "Lava e pettina le ciglia ogni giorno con shampoo, pennello e pettinino",
  "Puoi usare le lenti a contatto",
  "Non strappare le ciglia: per la rimozione affidati a me",
];

function Index() {
  return (
    <main className="min-h-screen overflow-x-hidden bg-background text-foreground">
      <section className="relative h-screen hero-bg">
        <div className="absolute inset-0"><Hero3D /></div>
        <div className="pointer-events-none relative z-10 flex h-full flex-col items-center justify-center px-6 text-center">
          <p className="font-display text-lg tracking-[0.3em] text-primary uppercase">Lash atelier · Torino</p>
          <h1 className="font-script mt-4 text-7xl text-primary drop-glow md:text-9xl">Ami Beauté</h1>
          <p className="font-display mt-2 text-2xl text-foreground md:text-3xl">Atelier di extension ciglia 🎀</p>
          <div className="pointer-events-auto mt-10 flex flex-wrap justify-center gap-4">
            <a href={IG} target="_blank" rel="noreferrer" className="btn-kitty">Prenota su Instagram</a>
            <a href={TT} target="_blank" rel="noreferrer" className="btn-kitty-outline">Guarda su TikTok</a>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 py-24">
        <h2 className="section-title">I nostri lavori</h2>
        <div className="mt-12 grid grid-cols-2 gap-6 md:grid-cols-3">
          {photos.map((p) => (
            <Tilt key={p.src}>
              <img src={p.src} alt={p.label} loading="lazy" className="aspect-[3/4] w-full object-cover" />
              <span className="tilt-label">{p.label}</span>
            </Tilt>
          ))}
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-8 px-6 pb-24 md:grid-cols-2">
        <Tilt className="info-card">
          <h3 className="font-display text-3xl font-bold text-primary">Policy 🎀</h3>
          <ul className="mt-6 space-y-3">{policy.map((t) => <li key={t} className="bullet">{t}</li>)}</ul>
          <p className="mt-6 font-semibold">Portate il vostro blush e la vostra combo labbra preferita per foto da vera baddie nella postazione social ❤️</p>
        </Tilt>
        <Tilt className="info-card">
          <h3 className="font-display text-3xl font-bold text-primary">Aftercare 🫧</h3>
          <p className="mt-6 text-muted-foreground">Se curate, le extension durano fino a 5/6 settimane. Ogni giorno perdiamo dalle 3 alle 7 ciglia naturali, quindi è normale che si sfoltiscano col tempo.</p>
          <ul className="mt-6 space-y-3">{aftercare.map((t) => <li key={t} className="bullet">{t}</li>)}</ul>
        </Tilt>
      </section>

      <section className="contact-bg px-6 py-24 text-center">
        <h2 className="section-title">Vieni a trovarmi</h2>
        <p className="font-display mt-6 text-2xl">📍 Via Moncalieri, Torino, Italy</p>
        <div className="mt-10 flex flex-wrap justify-center gap-6">
          <Tilt className="contact-card">
            <a href={IG} target="_blank" rel="noreferrer" className="block p-8">
              <p className="text-sm uppercase tracking-widest text-muted-foreground">Instagram</p>
              <p className="font-display mt-2 text-2xl font-bold text-primary">@ami_beauteatelier</p>
            </a>
          </Tilt>
          <Tilt className="contact-card">
            <a href={TT} target="_blank" rel="noreferrer" className="block p-8">
              <p className="text-sm uppercase tracking-widest text-muted-foreground">TikTok</p>
              <p className="font-display mt-2 text-2xl font-bold text-primary">@ami_beauteatlier</p>
            </a>
          </Tilt>
        </div>
        <p className="font-script mt-16 text-4xl text-primary">con amore, Ami 💗</p>
      </section>
    </main>
  );
}
