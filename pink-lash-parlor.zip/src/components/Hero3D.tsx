import { Canvas, useFrame } from "@react-three/fiber";
import { Environment, Float, Lightformer, Sparkles } from "@react-three/drei";
import { useMemo, useRef } from "react";
import * as THREE from "three";

function heartShape() {
  const s = new THREE.Shape();
  s.moveTo(0, 0.5);
  s.bezierCurveTo(0, 0.8, -0.5, 1, -0.9, 0.7);
  s.bezierCurveTo(-1.3, 0.3, -1, -0.3, 0, -1);
  s.bezierCurveTo(1, -0.3, 1.3, 0.3, 0.9, 0.7);
  s.bezierCurveTo(0.5, 1, 0, 0.8, 0, 0.5);
  return s;
}

function Heart({ position, scale = 1, color = "#ff5fa2" }: { position: [number, number, number]; scale?: number; color?: string }) {
  const geo = useMemo(
    () => new THREE.ExtrudeGeometry(heartShape(), { depth: 0.35, bevelEnabled: true, bevelSize: 0.12, bevelThickness: 0.12, bevelSegments: 6, curveSegments: 24 }).center(),
    [],
  );
  const ref = useRef<THREE.Mesh>(null);
  useFrame((_, d) => { if (ref.current) ref.current.rotation.y += d * 0.6; });
  return (
    <Float speed={2} rotationIntensity={0.4} floatIntensity={1.4}>
      <mesh ref={ref} geometry={geo} position={position} scale={scale}>
        <meshPhysicalMaterial color={color} roughness={0.15} clearcoat={1} clearcoatRoughness={0.1} />
      </mesh>
    </Float>
  );
}

function Bow({ position, scale = 1 }: { position: [number, number, number]; scale?: number }) {
  const ref = useRef<THREE.Group>(null);
  useFrame((s) => { if (ref.current) ref.current.rotation.z = Math.sin(s.clock.elapsedTime) * 0.25; });
  const mat = <meshPhysicalMaterial color="#e8174f" roughness={0.25} clearcoat={1} />;
  return (
    <Float speed={1.5} floatIntensity={1.2}>
      <group ref={ref} position={position} scale={scale}>
        <mesh position={[-0.75, 0, 0]} rotation={[0, 0, -Math.PI / 2]} scale={[1, 1, 0.55]}>
          <coneGeometry args={[0.65, 1.3, 32]} />{mat}
        </mesh>
        <mesh position={[0.75, 0, 0]} rotation={[0, 0, Math.PI / 2]} scale={[1, 1, 0.55]}>
          <coneGeometry args={[0.65, 1.3, 32]} />{mat}
        </mesh>
        <mesh><sphereGeometry args={[0.32, 32, 32]} />{mat}</mesh>
      </group>
    </Float>
  );
}

function Pearl({ position, r }: { position: [number, number, number]; r: number }) {
  return (
    <Float speed={3} floatIntensity={2}>
      <mesh position={position}>
        <sphereGeometry args={[r, 32, 32]} />
        <meshPhysicalMaterial color="#fff0f6" roughness={0.1} metalness={0.2} clearcoat={1} iridescence={1} />
      </mesh>
    </Float>
  );
}

function Rig() {
  useFrame((s) => {
    s.camera.position.x = THREE.MathUtils.lerp(s.camera.position.x, s.pointer.x * 1.2, 0.05);
    s.camera.position.y = THREE.MathUtils.lerp(s.camera.position.y, s.pointer.y * 0.8, 0.05);
    s.camera.lookAt(0, 0, 0);
  });
  return null;
}

export function Hero3D() {
  return (
    <Canvas dpr={[1, 2]} camera={{ position: [0, 0, 9], fov: 50 }}>
      <ambientLight intensity={0.8} />
      <directionalLight position={[5, 6, 5]} intensity={1.6} />
      <Environment>
        <Lightformer intensity={2} position={[0, 5, 0]} scale={[10, 10, 1]} />
        <Lightformer intensity={1.5} color="#ffc0dc" position={[-5, 1, -1]} rotation-y={Math.PI / 2} scale={[20, 2, 1]} />
      </Environment>
      <Heart position={[-3.6, 1.6, 0]} scale={0.9} />
      <Heart position={[3.8, -1.4, -1]} scale={1.1} color="#ff8cc0" />
      <Heart position={[2.8, 2.4, -2]} scale={0.5} color="#ffb3d4" />
      <Heart position={[-2.6, -2.3, -1]} scale={0.6} color="#ff3d8b" />
      <Bow position={[3.4, 1, 1]} scale={0.6} />
      <Bow position={[-4, -0.6, -2]} scale={0.5} />
      <Pearl position={[-1.5, 2.8, -1]} r={0.25} />
      <Pearl position={[1.2, -2.8, 0]} r={0.35} />
      <Pearl position={[4.6, 0.4, -3]} r={0.2} />
      <Pearl position={[-4.8, 2.4, -3]} r={0.3} />
      <Sparkles count={80} scale={[14, 8, 4]} size={4} color="#ffffff" speed={0.4} />
      <Rig />
    </Canvas>
  );
}
